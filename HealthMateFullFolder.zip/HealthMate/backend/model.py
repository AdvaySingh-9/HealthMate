import os
import sys
import base64
from pathlib import Path
from huggingface_hub import hf_hub_download
from llama_cpp import Llama
from llama_cpp.llama_chat_format import Llava15ChatHandler
from backend.image_clean import ImageProcessor
from PyPDF2 import PdfReader
import re


class Gemma4Model:

    # Initialize model with prompt and optional files
    def __init__(self, prompt, files=None):

        self.prompt = prompt
        self.files = files or []

        # System instruction for healthcare assistant behavior
        self.system_instruction = """
        ...
        """


    # Generate response from model
    def answer(self):

        # Download main GGUF model
        m_path = hf_hub_download(
            repo_id="unsloth/gemma-4-E2B-it-GGUF",
            filename="gemma-4-E2B-it-Q4_K_M.gguf"
        )

        # Download multimodal projection model
        c_path = hf_hub_download(
            repo_id="unsloth/gemma-4-E2B-it-GGUF",
            filename="mmproj-BF16.gguf"
        )

        # Store all user content here
        content_payload = []

        processor = ImageProcessor()

        # Process uploaded files
        for file_path in self.files:

            ext = Path(file_path).suffix.lower()

            # Handle PDF files
            if ext == ".pdf":

                try:
                    reader = PdfReader(file_path)

                    pdf_text = ""

                    # Extract text from all PDF pages
                    for page in reader.pages:

                        extracted = page.extract_text()

                        if extracted:

                            cleaned = extracted.replace("\n", " ")
                            cleaned = re.sub(r"\s+", " ", cleaned)

                            pdf_text += cleaned + "\n"

                    # Add extracted PDF text
                    if pdf_text.strip():

                        content_payload.append({
                            "type": "text",
                            "text": f"PDF CONTENT:\n{pdf_text}"
                        })

                except Exception as e:

                    content_payload.append({
                        "type": "text",
                        "text": f"Could not read PDF: {str(e)}"
                    })

            # Handle image files
            elif ext in [".png", ".jpg", ".jpeg"]:

                try:

                    # Clean and process image
                    processed = processor.process(file_path)

                    # Temporary processed image path
                    temp_output = str(
                        Path(file_path).with_name(
                            f"processed_{Path(file_path).name}"
                        )
                    )

                    # Save processed image
                    processor.save(processed, temp_output)

                    # Convert image to base64
                    with open(temp_output, "rb") as f:

                        encoded = base64.b64encode(
                            f.read()
                        ).decode("utf-8")

                    # Add image payload
                    content_payload.append({
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{encoded}"
                        }
                    })

                except Exception as e:

                    content_payload.append({
                        "type": "text",
                        "text": f"Could not process image: {str(e)}"
                    })

        # Add user prompt
        content_payload.append({
            "type": "text",
            "text": self.prompt
        })

        llm = None

        try:

            # Setup multimodal chat handler
            handler = Llava15ChatHandler(
                clip_model_path=c_path,
                verbose=False
            )

            # Load Llama model
            llm = Llama(
                model_path=m_path,
                chat_handler=handler,
                n_ctx=4096,
                verbose=False
            )

            # Generate AI response
            response = llm.create_chat_completion(

                messages=[
                    {
                        "role": "system",
                        "content": self.system_instruction
                    },
                    {
                        "role": "user",
                        "content": content_payload
                    }
                ],

                max_tokens=700,
                temperature=0.4,
                top_p=0.9,
                top_k=40,
                repeat_penalty=1.1,
                stop=["</s>"]
            )

            # Extract final answer
            answer = response["choices"][0]["message"]["content"]

            return answer.strip()

        except Exception as e:

            return f"Error: {str(e)}"

        finally:

            # Free model memory
            if llm:
                llm.close()