import cv2 as cv
import numpy as np
from pathlib import Path


class ImageProcessor:

    # Initialize image processing settings
    def __init__(
        self,
        target_size=(768, 768),
        jpeg_quality=80,
        clahe_clip=2.0,
        clahe_grid=(8, 8)
    ):

        self.target_size = target_size
        self.jpeg_quality = jpeg_quality

        # CLAHE improves local contrast
        self.clahe = cv.createCLAHE(
            clipLimit=clahe_clip,
            tileGridSize=clahe_grid
        )

    
    # Load image from path or numpy array
    def load_image(self, img_input):
        if isinstance(img_input, str):
            img = cv.imread(img_input)

        elif isinstance(img_input, np.ndarray):
            img = img_input

        else:
            raise ValueError(
                "Unsupported input type. "
                "Provide file path or numpy array."
            )

        # Check if image loaded correctly
        if img is None:
            raise ValueError(
                "Could not load image."
            )

        return img

   
    # Convert image to grayscale and enhance it
    def grayscale(self, img):

        # Convert to grayscale
        gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

        # Remove noise
        gray = cv.fastNlMeansDenoising(gray)

        # Improve contrast
        gray = self.clahe.apply(gray)

        return gray

    
    # Resize image while keeping aspect ratio
    def resize(self, img):

        h, w = img.shape[:2]
        target_w, target_h = self.target_size

        # Compute resize scale
        scale = min(target_w / w, target_h / h)

        # Prevent upscaling
        scale = min(scale, 1.0)

        new_w = int(w * scale)
        new_h = int(h * scale)

        resized = cv.resize(
            img,
            (new_w, new_h),
            interpolation=cv.INTER_AREA
        )

        return resized

   
    # Sharpen image using convolution kernel
    def sharpen(self, img):

        kernel = np.array([
            [0, -1, 0],
            [-1, 5, -1],
            [0, -1, 0]
        ])

        sharp = cv.filter2D(
            img,
            -1,
            kernel
        )

        return sharp
    

    # Complete image processing pipeline
    def process(self, img_input):

        img = self.load_image(img_input)

        resized = self.resize(img)

        gray = self.grayscale(resized)

        sharp = self.sharpen(gray)

        return sharp
    

    # Save processed image
    def save(self, img, output_path):

        cv.imwrite(
            output_path,
            img,
            [cv.IMWRITE_JPEG_QUALITY, self.jpeg_quality]
        )

        return output_path