from model import Gemma4Model


PROMPT = """
Explain + What Value is Less and what is Good , how to maintain Good ones and How to fix Bad ones in this report?:-

Blood Test Report
Patient Name: John Doe
Age/Sex: 32 / Male
Date: 10 May 2026

Red Blood Cell (RBC) Section
RBC Count: 4.2 million/µL
Hemoglobin: 11.2 g/dL
Hematocrit: 36%
MCV: 78 fL
MCH: 25 pg
MCHC: 31 g/dL
RDW: 16%

White Blood Cell (WBC) Section
Total WBC Count: 12,500/µL
Differential Count:
Neutrophils: 75%
Lymphocytes: 18%
Monocytes: 4%
Eosinophils: 2%
Basophils: 1%

Platelet Section
Platelet Count: 480,000/µL
MPV: 12.0 fL

"""
model = Gemma4Model(prompt=PROMPT)

print(model.answer())